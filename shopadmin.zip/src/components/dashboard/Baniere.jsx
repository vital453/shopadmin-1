// import React from 'react';
// import { Element, animateScroll as scroll } from 'react-scroll';

const Baniere = () => {
//   const scrollToMessage = () => {
//     scroll.scrollTo(
//       "messageflefhlkehflehkfhlehflkhelfhelkhfkehflehflehfhlehfhelflhehfehf ffkefjehflekfjehf fefkehfhejfegfegfhegfef fefjdkfhekfenfefkbekjfj fhefebfkbfkebfgfgfekfjkjdkjbckjefhhfe",
//       {
//         duration: 1000,
//         delay: 100,
//         smooth: true,
//       }
//     );
//   };
  return (
    <div>
      {/* <button onClick={scrollToMessage}>Défiler</button>
      <Element name="message" className="element">
        Ton message ici...
      </Element> */}
    </div>
  );
};

export default Baniere;
