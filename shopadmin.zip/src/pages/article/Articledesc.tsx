import React from 'react';
import Description from '../../components/articles/description';


const Articledesc: React.FC = () => {
    return (
        <>
          
        </>
    );
};
export default Articledesc;