import { Store } from "pullstate";

export const ProductStore = new Store({
    
    products: []
});