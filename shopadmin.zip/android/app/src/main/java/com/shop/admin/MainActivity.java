package com.shop.admin;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
